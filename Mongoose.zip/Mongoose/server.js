const express = require("express");
const db = require("./config/db");
const User = require("./model/UserModel");

const app = express();

// Middleware
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Server is working!");
});

// POST API
app.post("/User", async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = new User({
      username,
      password
    });

    const savedUser = await user.save();

    res.status(201).json(savedUser);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.listen(8203, () => {
  console.log("Server running on port 8203");
});